package com.bdtopcoder.chatgpt;

public class API {
    public static String API_URL = "https://api.openai.com/v1/completions";
    public static String API = "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";
}
